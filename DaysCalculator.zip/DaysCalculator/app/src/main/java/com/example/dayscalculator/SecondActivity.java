package com.example.dayscalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SecondActivity extends AppCompatActivity {

    TextView textView_year,textView_month,textView_date,textView_hours,textView_mins,textView_secs,textView_hb,textView_smiles;
    NumberPicker numberPicker_year,numberPicker_month,numberPicker_date;
    ConstraintLayout constraintLayout_below,constraintLayout_above;
    Button button_calculate;
    String currentDate = new SimpleDateFormat("ddMMyyyy", Locale.getDefault()).format(new Date());
    String currentTime = new SimpleDateFormat("HHmmss", Locale.getDefault()).format(new Date());
    int year,month,date,Cyear,Cmonth,Cdate,Chour,Cmin,Csec;
    MediaPlayer tickSound,applause;
    String name;
    long noOfSmiles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        overridePendingTransition(R.xml.fadein, R.xml.fadeout);
        getSupportActionBar().hide(); //hide the title bar
        tickSound=MediaPlayer.create(this,R.raw.tick);
        applause=MediaPlayer.create(this,R.raw.fireworks);
        Intent caller=getIntent();
        name=caller.getStringExtra("name");

        textView_year=(TextView)findViewById(R.id.textView_year);
        textView_month=(TextView)findViewById(R.id.textView_month);
        textView_date=(TextView)findViewById(R.id.textView_date);
        numberPicker_year=(NumberPicker)findViewById(R.id.numberPicker_year);
        numberPicker_month=(NumberPicker)findViewById(R.id.numberPicker_month);
        numberPicker_date=(NumberPicker)findViewById(R.id.numberPicker_date);
        constraintLayout_below=(ConstraintLayout)findViewById(R.id.constraintLayout_below);
        constraintLayout_above=(ConstraintLayout)findViewById(R.id.constraintLayout_above);
        button_calculate=(Button)findViewById(R.id.button_calculate);
        textView_smiles=(TextView)findViewById(R.id.textView_smiles);
        textView_hours=(TextView)findViewById(R.id.textView_hours);
        textView_mins=(TextView)findViewById(R.id.textView_mins);
        textView_secs=(TextView)findViewById(R.id.textView_secs);
        textView_hb=(TextView)findViewById(R.id.textView_hb);

        Cdate=Integer.parseInt(currentDate.charAt(0)+""+currentDate.charAt(1));
        Cmonth=Integer.parseInt(currentDate.charAt(2)+""+currentDate.charAt(3));
        Cyear=Integer.parseInt(currentDate.charAt(4)+""+currentDate.charAt(5)+""+currentDate.charAt(6)+""+currentDate.charAt(7));
        Chour=Integer.parseInt(currentTime.charAt(0)+""+currentTime.charAt(1));
        Cmin=Integer.parseInt(currentTime.charAt(2)+""+currentTime.charAt(3));
        Csec=Integer.parseInt(currentTime.charAt(4)+""+currentTime.charAt(5));

        numberPicker_month.setVisibility(View.INVISIBLE);
        textView_month.setVisibility(View.INVISIBLE);
        numberPicker_date.setVisibility(View.INVISIBLE);
        textView_date.setVisibility(View.INVISIBLE);
        constraintLayout_below.setVisibility(View.INVISIBLE);
        button_calculate.setVisibility(View.INVISIBLE);

        numberPicker_year.setMinValue(1900);
        numberPicker_year.setMaxValue(2020);

        numberPicker_year.setOnScrollListener(new NumberPicker.OnScrollListener() {
            @Override
            public void onScrollStateChange(NumberPicker numberPicker, int i) {
                numberPicker_month.setVisibility(View.VISIBLE);
                textView_month.setVisibility(View.VISIBLE);
                year=numberPicker_year.getValue();
                numberPicker_month.setMinValue(01);;
                if(year==2020)
                    numberPicker_month.setMaxValue(Cmonth);
                else
                    numberPicker_month.setMaxValue(12);
                tickSound.start();
            }
        });
        /*numberPicker_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                numberPicker_month.setVisibility(View.VISIBLE);
                textView_month.setVisibility(View.VISIBLE);
                year=numberPicker_year.getValue();
                numberPicker_month.setMinValue(01);;
                if(year==2020)
                    numberPicker_month.setMaxValue(Cmonth);
                else
                    numberPicker_month.setMaxValue(12);
                tickSound.start();
            }
        });*/

        numberPicker_month.setOnScrollListener(new NumberPicker.OnScrollListener(){

            @Override
            public void onScrollStateChange(NumberPicker numberPicker, int i) {
                numberPicker_date.setVisibility(View.VISIBLE);
                textView_date.setVisibility(View.VISIBLE);
                month=numberPicker_month.getValue();
                numberPicker_date.setMinValue(1);
                if(month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12)
                    numberPicker_date.setMaxValue(31);
                else if(month==2) {
                    if (((year % 4 == 0 && year % 100 != 0) || year % 400 == 0))
                        numberPicker_date.setMaxValue(29);
                    else
                        numberPicker_date.setMaxValue(28);
                }
                else
                    numberPicker_date.setMaxValue(30);
                tickSound.start();
            }
        });
        /*numberPicker_month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                numberPicker_date.setVisibility(View.VISIBLE);
                textView_date.setVisibility(View.VISIBLE);
                month=numberPicker_month.getValue();
                numberPicker_date.setMinValue(1);
                    if(month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12)
                        numberPicker_date.setMaxValue(31);
                    else if(month==2) {
                        if (((year % 4 == 0 && year % 100 != 0) || year % 400 == 0))
                            numberPicker_date.setMaxValue(29);
                        else
                            numberPicker_date.setMaxValue(28);
                    }
                    else
                        numberPicker_date.setMaxValue(30);
                tickSound.start();
            }
        });*/

        numberPicker_date.setOnScrollListener(new NumberPicker.OnScrollListener() {
            @Override
            public void onScrollStateChange(NumberPicker numberPicker, int i) {
                date=numberPicker_date.getValue();
                button_calculate.setVisibility(View.VISIBLE);
                tickSound.start();
            }
        });
        /*numberPicker_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                date=numberPicker_date.getValue();
                button_calculate.setVisibility(View.VISIBLE);
                tickSound.start();
            }
        });*/
    }

    public long daysCalculate(int d1,int m1,int y1,int d2,int m2,int y2)
    {
        int m[]={31,28,31,30,31,30,31,31,30,31,30,31};
        long d=0;
        if(y1<y2)
        {
            if((y1%4==0&&y1%100!=0)||y1%400==0)
                m[1]=29;
            d+=m[m1-1]-d1;
            for(int i=m1;i<12;i++)
                d+=m[i];
            if((y2%4==0&&y2%100!=0)||y2%400==0)
                m[1]=29;
            else
                m[1]=28;
            d+=d2;
            for(int i=0;i<m2-1;i++)
                d+=m[i];
            d+=(long)(y2-y1-1)*365;
            //if(m2>m1 || (m1==m2 && d2>d1))
              //  d+=365;
            d+=(y2-y1)/4;
        }
        else
        {
            if(m1<m2)
            {
                if((y1%4==0&&y1%100!=0)||y1%400==0)
                    m[1]=29;
                d+=m[m1-1]-d1;
                for(int i=m1+1;i<m2-1;i++)
                    d+=m[i];
                if((y2%4==0&&y2%100!=0)||y2%400==0)
                    m[1]=29;
                else
                    m[1]=28;
                d+=d2;
            }
            else
                d+=d2-d1;
        }
        return d;
    }
    public void calculate(View v)
    {
        long noOfHours,noOfMins,noOfSecs,noOfHb;
        long noOfDays=daysCalculate(date,month,year,Cdate,Cmonth,Cyear);

            noOfHours = noOfDays * 24 + Chour;
            noOfMins = noOfHours * 60 + Cmin;
            noOfSecs = noOfMins * 60 + Csec;
            noOfHb = noOfMins * 70;
            if (noOfDays / 365 < 3)
                noOfSmiles = noOfDays * 400;
            else
                noOfSmiles = noOfDays * 30 + 40000;
            textView_hours.setText(Long.toString(noOfHours));
            textView_mins.setText(Long.toString(noOfMins));

            textView_hb.setText(Long.toString(noOfHb));
            textView_smiles.setText(Long.toString(noOfSmiles));
            constraintLayout_below.setVisibility(View.VISIBLE);
            textView_secs.setText(Long.toString(noOfSecs));
            if(date==Cdate &&month==Cmonth)
            {
                /*Intent goToBirthday=new Intent();
                goToBirthday.setClass(this,Birthday.class);
                goToBirthday.putExtra("name",name);
                startActivity(goToBirthday);*/
                constraintLayout_above.setBackgroundResource(R.drawable.back);
                constraintLayout_below.setBackgroundResource(R.drawable.back);
                Toast.makeText(this, "Happy Birthday "+name, Toast.LENGTH_LONG).show();
                applause.start();
            }
    }
    public void reset(View view)
    {
        Intent goToSecond=new Intent();
        goToSecond.setClass(this,SecondActivity.class);
        goToSecond.putExtra("name",name);
        finish();
        startActivity(goToSecond);
    }
    public void send(View v)
    {
        Intent goToThird=new Intent();
        goToThird.setClass(this,ThirdActivity.class);
        goToThird.putExtra("name",name);
        goToThird.putExtra("smiles",noOfSmiles);
        startActivity(goToThird);
    }
}
