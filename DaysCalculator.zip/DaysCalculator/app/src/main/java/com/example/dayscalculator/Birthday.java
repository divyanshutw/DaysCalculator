package com.example.dayscalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class Birthday extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_birthday);

        getSupportActionBar().hide(); //hide the title bar

        String name;
        Intent intent=getIntent();
        name=intent.getStringExtra("name");
        Toast.makeText(this, "Happy Birthday "+name, Toast.LENGTH_LONG).show();
        VideoView videoView=(VideoView)findViewById(R.id.videoView);
        MediaController mediaController=new MediaController(this);
        mediaController.setAnchorView(mediaController);
        //Uri uri=Uri.parse("file:///android_asset/animatedbirthday.gif");
        //videoView.setVideoURI(uri);
        videoView.setVideoPath("file:///android_asset/n.mp4");
        videoView.requestFocus();
        videoView.setMediaController(mediaController);
        videoView.start();


        MediaPlayer sound1=MediaPlayer.create(this,R.raw.fireworks);

        sound1.start();
        sound1.setLooping(true);


    }
}
