package com.example.dayscalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ThirdActivity extends AppCompatActivity {

    MediaPlayer tickSound;
    String relative,name;
    boolean flag_relative_selected=false;
    EditText editText_no,editText_message;

    String no,message;
    long noOfSmiles;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        getSupportActionBar().hide(); //hide the title bar
        overridePendingTransition(R.xml.fadein, R.xml.fadeout);
        tickSound=MediaPlayer.create(this,R.raw.tick);
        editText_no=(EditText) findViewById(R.id.editText_no);
        editText_message=(EditText)findViewById(R.id.editText_message);
        editText_message.setVisibility(View.INVISIBLE);

        ListView listView=(ListView)findViewById(R.id.listView_relative);
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Father");
        arrayList.add("Mother");
        arrayList.add("Bro");
        arrayList.add("Sis");
        arrayList.add("Other");
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);
        Intent intent=getIntent();
        name=intent.getStringExtra("name");
        noOfSmiles=intent.getLongExtra("smiles",0);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                tickSound.start();
                relative=arrayAdapter.getItem(i);
                flag_relative_selected=true;
                message="Dear "+relative+",\n"+name+" here,I smiled "+noOfSmiles+" times throughout my life and you were the reason for each one.";
                editText_message.setText(message);
                editText_message.setVisibility(View.VISIBLE);
            }
        });




    }
    public void sendMessage(View v)
    {

        if(flag_relative_selected==false)
            Toast.makeText(this, "Select relative to send message", Toast.LENGTH_SHORT).show();
        else
        {
            no=editText_no.getText().toString();
            if(no.length()<10)
                Toast.makeText(this, "Enter valid phone no.", Toast.LENGTH_SHORT).show();
            else
            {
                Uri destination = Uri.parse("smsto:"+no);
                Intent smsIntent=new Intent(Intent.ACTION_SENDTO,destination);
                smsIntent.putExtra("sms_body",message);
                startActivity(smsIntent);
            }
        }
    }
}
