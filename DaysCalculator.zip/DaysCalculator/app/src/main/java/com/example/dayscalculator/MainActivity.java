package com.example.dayscalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide(); //hide the title bar
        editText=(EditText)findViewById(R.id.editText_name);
    }
    public void startSecondActivity(View v)
    {
        String name=editText.getText().toString();
        Intent goToSecond=new Intent();
        goToSecond.setClass(this,SecondActivity.class);
        goToSecond.putExtra("name",name);
        if(name.length()==0)
            Toast.makeText(this, "Enter your name to proceed", Toast.LENGTH_SHORT).show();
        else
        {
            Toast.makeText(this, "Welcome "+name, Toast.LENGTH_SHORT).show();
            startActivity(goToSecond);
        }

    }
}
